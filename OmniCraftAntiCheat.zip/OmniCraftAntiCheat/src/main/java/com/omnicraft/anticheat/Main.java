package com.omnicraft.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

    @Override
    public void onEnable() {
        getLogger().info("OmniCraftAntiCheat is now enabled!");

        // Register event listeners
        Bukkit.getServer().getPluginManager().registerEvents(new PlayerListener(this), this);

        // Load the configuration file
        saveDefaultConfig();
    }

    @Override
    public void onDisable() {
        getLogger().info("OmniCraftAntiCheat has been disabled!");
    }
}